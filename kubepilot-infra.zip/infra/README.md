# KubePilot infrastructure: one Azure VM + registry + identity

Creates: resource group, VNet + subnet, static public IP, NSG (SSH and the web app only, from IPs you list),
an Ubuntu 24.04 VM (SSH key only), a user-assigned managed identity attached to the VM, and an Azure Container
Registry (ACR, the Azure equivalent of AWS ECR) where the identity can pull (and, optionally, push) images.

Not created here: Azure OpenAI, AI Search, PostgreSQL, Key Vault, Blob Storage (you create those separately).

## 0. Before you start
- **Your laptop's public IP:** open https://api.ipify.org in a browser on the machine you will SSH from. Use it as `x.x.x.x/32`.
  Do not use Cloud Shell's IP; it changes.
- **SSH key (on your laptop):** `ssh-keygen -t ed25519` then show the public key with `cat ~/.ssh/id_ed25519.pub`.
- **Image name check (optional):** `az vm image list --publisher Canonical --offer ubuntu-24_04-lts --all -o table` should list `server` SKUs.
- **Quota:** `az vm list-usage -l <region> -o table` and check you have free vCPUs of the family you choose.

## 1. Run Terraform from Azure Cloud Shell (Bash)
Cloud Shell already has Terraform and is already logged in. Check: `terraform version` and `az account show`.
```bash
# upload this infra folder (zip) with the Cloud Shell "Upload" button, then:
unzip kubepilot-infra.zip && cd infra/terraform

export ARM_SUBSCRIPTION_ID=$(az account show --query id -o tsv)
cp terraform.tfvars.example terraform.tfvars
nano terraform.tfvars        # set location, ssh_public_key, ssh_allowed_cidrs; adjust vm_size / os_disk_gb

terraform init
terraform plan -out tfplan   # read it: ~12 resources to add, nothing to destroy
terraform apply tfplan
terraform output             # note public_ip, acr_name, identity_client_id
```
The state file stays in Cloud Shell's persistent storage (`terraform.tfstate`). Back it up; for a team, move it to a
storage account backend later. `terraform destroy` removes everything, including the registry and its images.

## 2. Change CPU / memory later
Edit `vm_size` (and `os_disk_gb`) in `terraform.tfvars`, then `terraform plan` and `terraform apply`.
Resizing restarts the VM. The disk can grow but cannot shrink.

## 3. Prepare the VM
```bash
scp infra/scripts/bootstrap-vm.sh azureuser@<public_ip>:~     # from your laptop
ssh azureuser@<public_ip>
bash bootstrap-vm.sh        # installs git, unzip, Docker Engine + Compose, Azure CLI
```
Log out and back in once so the `docker` group applies. Then `git clone <your-repo>` and follow the main README.

## 4. Grant the identity access to your Azure OpenAI and AI Search (portal)
Identity name: output `identity_name` (default `kubepilot-id`). Assign, under each resource's Access control (IAM):
- Azure OpenAI: **Cognitive Services OpenAI User**
- AI Search: **Search Index Data Reader** (runtime); **Search Service Contributor** and **Search Index Data Contributor** only while seeding/ingesting
Then on the VM add `AZURE_CLIENT_ID=<identity_client_id>` to `.env` (output `env_snippet`) and leave the key variables empty.

## 5. Push and pull images with ACR (no passwords; the admin user is disabled)
On the VM:
```bash
az login --identity --client-id <identity_client_id>
az acr login --name <acr_name>

docker compose build
docker tag kubepilot-backend:dev  <acr_login_server>/kubepilot-backend:0.1
docker tag kubepilot-frontend:dev <acr_login_server>/kubepilot-frontend:0.1
docker push <acr_login_server>/kubepilot-backend:0.1
docker push <acr_login_server>/kubepilot-frontend:0.1
```
Pull from anywhere the identity is available: `docker pull <acr_login_server>/kubepilot-backend:0.1`.
The compose file still builds locally by default; switch its `image:` lines to the ACR names when you want to run from the registry.
Later, AKS gets pull access by granting its kubelet identity `AcrPull` on this registry.

## Security notes
- The web app has **no login and uses plain HTTP**. Keep `app_allowed_cidrs` narrow. Port 8000 is never opened.
- Docker-published ports are not blocked by the VM's `ufw`; the NSG is the real firewall.
- `terraform.tfvars` is git-ignored. Commit `.terraform.lock.hcl` so provider versions stay pinned.
- Cost: the VM, disk, static public IP and ACR bill while they exist. Stop compute billing with `az vm deallocate -g kubepilot-rg -n kubepilot-vm`.
