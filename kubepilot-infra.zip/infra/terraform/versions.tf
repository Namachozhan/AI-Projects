terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}

  # azurerm 4.x needs a subscription. In Cloud Shell leave var.subscription_id
  # null and run first:  export ARM_SUBSCRIPTION_ID=$(az account show --query id -o tsv)
  subscription_id = var.subscription_id
}
