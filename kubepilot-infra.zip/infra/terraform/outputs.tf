output "public_ip" {
  description = "Public IP address of the VM."
  value       = azurerm_public_ip.vm.ip_address
}

output "ssh_command" {
  description = "Connect to the VM (from a machine whose IP is in ssh_allowed_cidrs)."
  value       = "ssh ${var.admin_username}@${azurerm_public_ip.vm.ip_address}"
}

output "app_url" {
  description = "Where the KubePilot frontend will be reachable once docker compose is up (plain HTTP)."
  value       = "http://${azurerm_public_ip.vm.ip_address}:${var.app_port}"
}

output "acr_name" {
  description = "Container registry name (use with: az acr login --name)."
  value       = azurerm_container_registry.acr.name
}

output "acr_login_server" {
  description = "Registry host for image names, e.g. <acr_login_server>/kubepilot-backend:0.1"
  value       = azurerm_container_registry.acr.login_server
}

output "identity_name" {
  description = "Name of the user-assigned managed identity. Grant it roles on Azure OpenAI and AI Search in the portal."
  value       = azurerm_user_assigned_identity.vm.name
}

output "identity_client_id" {
  description = "Put this in the VM's .env as AZURE_CLIENT_ID so the apps pick this identity."
  value       = azurerm_user_assigned_identity.vm.client_id
}

output "identity_principal_id" {
  description = "Object (principal) id of the identity, for role assignments by CLI."
  value       = azurerm_user_assigned_identity.vm.principal_id
}

output "env_snippet" {
  description = "Lines to add to .env on the VM."
  value       = "AZURE_CLIENT_ID=${azurerm_user_assigned_identity.vm.client_id}"
}
