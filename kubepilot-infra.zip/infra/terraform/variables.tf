# ---------------------------------------------------------------------------
# Required: no default on purpose. Set these in terraform.tfvars.
# ---------------------------------------------------------------------------

variable "location" {
  description = "Azure region, e.g. \"westeurope\". Use the same region as your Azure OpenAI and AI Search, and check you have vCPU quota for vm_size there."
  type        = string
}

variable "ssh_public_key" {
  description = "Contents of your SSH PUBLIC key (the .pub file), e.g. \"ssh-ed25519 AAAA... you@laptop\". Never paste the private key."
  type        = string

  validation {
    condition     = startswith(trimspace(var.ssh_public_key), "ssh-") || startswith(trimspace(var.ssh_public_key), "ecdsa-")
    error_message = "ssh_public_key must be a public key line starting with ssh- or ecdsa-. Do not use the private key."
  }
}

variable "ssh_allowed_cidrs" {
  description = "Source IP ranges allowed to SSH to the VM, e.g. [\"203.0.113.10/32\"] (your laptop's public IP). Open-to-the-world SSH is rejected."
  type        = list(string)

  validation {
    condition     = length(var.ssh_allowed_cidrs) > 0 && alltrue([for c in var.ssh_allowed_cidrs : can(cidrhost(c, 0))])
    error_message = "ssh_allowed_cidrs must be a non-empty list of valid CIDR ranges such as 203.0.113.10/32."
  }

  validation {
    condition     = !contains(var.ssh_allowed_cidrs, "0.0.0.0/0")
    error_message = "SSH from 0.0.0.0/0 is blocked by this template. Use your own IP as x.x.x.x/32."
  }
}

# ---------------------------------------------------------------------------
# Optional: sensible defaults. Change as you like.
# ---------------------------------------------------------------------------

variable "subscription_id" {
  description = "Azure subscription id. Leave null in Cloud Shell and export ARM_SUBSCRIPTION_ID instead."
  type        = string
  default     = null
}

variable "prefix" {
  description = "Name prefix for every resource. Lowercase letters, digits and hyphens. Also used to build the ACR name."
  type        = string
  default     = "kubepilot"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{1,18}[a-z0-9]$", var.prefix))
    error_message = "prefix must be 3-20 characters: lowercase letters, digits and hyphens, starting with a letter."
  }
}

variable "tags" {
  description = "Extra tags added to every resource."
  type        = map(string)
  default     = {}
}

# ---- VM size: this is where you decide CPU and memory ----------------------

variable "vm_size" {
  description = <<-EOT
    VM size = CPU and memory. Examples (check current sizes and prices in your region):
      Standard_B2s     2 vCPU,  4 GiB  minimum; Docker builds are slow
      Standard_B2ms    2 vCPU,  8 GiB  default; comfortable for this project
      Standard_D2s_v5  2 vCPU,  8 GiB  steadier performance than B-series
      Standard_D4s_v5  4 vCPU, 16 GiB  headroom for big ingestion runs
    Check quota first:  az vm list-usage -l <region> -o table
  EOT
  type        = string
  default     = "Standard_B2ms"
}

variable "os_disk_gb" {
  description = "OS disk size in GB. Docker images, build cache and PDFs live here. 64 is a sensible start."
  type        = number
  default     = 64

  validation {
    condition     = var.os_disk_gb >= 30 && var.os_disk_gb <= 1024
    error_message = "os_disk_gb must be between 30 and 1024."
  }
}

variable "os_disk_type" {
  description = "StandardSSD_LRS (cheaper) or Premium_LRS (faster). Premium needs a VM size with an 's' (e.g. Standard_B2ms is fine)."
  type        = string
  default     = "StandardSSD_LRS"

  validation {
    condition     = contains(["Standard_LRS", "StandardSSD_LRS", "Premium_LRS"], var.os_disk_type)
    error_message = "os_disk_type must be Standard_LRS, StandardSSD_LRS or Premium_LRS."
  }
}

variable "admin_username" {
  description = "Linux admin user created on the VM. Password login is disabled; only your SSH key works."
  type        = string
  default     = "azureuser"
}

variable "image_offer" {
  description = "Marketplace image offer. Default is Ubuntu 24.04 LTS."
  type        = string
  default     = "ubuntu-24_04-lts"
}

variable "image_sku" {
  description = "Marketplace image SKU for the offer above (Gen2). For Ubuntu 22.04 use offer 0001-com-ubuntu-server-jammy and sku 22_04-lts-gen2."
  type        = string
  default     = "server"
}

# ---- Networking -------------------------------------------------------------

variable "vnet_cidr" {
  description = "Address space of the VNet. Large on purpose, so AKS, private-endpoint and agent subnets can be added later."
  type        = string
  default     = "10.10.0.0/16"
}

variable "vm_subnet_cidr" {
  description = "Subnet for the VM, inside vnet_cidr."
  type        = string
  default     = "10.10.1.0/24"
}

variable "app_port" {
  description = "Port the KubePilot frontend is published on (docker-compose maps 3000). The backend port 8000 is never opened."
  type        = number
  default     = 3000
}

variable "app_allowed_cidrs" {
  description = <<-EOT
    Source ranges allowed to open the web app. null = same as ssh_allowed_cidrs (recommended).
    The app has NO login yet and uses plain HTTP: do not use 0.0.0.0/0 with real documents.
  EOT
  type        = list(string)
  default     = null

  validation {
    condition     = var.app_allowed_cidrs == null ? true : alltrue([for c in var.app_allowed_cidrs : can(cidrhost(c, 0))])
    error_message = "app_allowed_cidrs must be null or a list of valid CIDR ranges."
  }
}

# ---- Container registry -----------------------------------------------------

variable "acr_sku" {
  description = "Basic (cheapest, fine here), Standard or Premium (needed later for private endpoints)."
  type        = string
  default     = "Basic"

  validation {
    condition     = contains(["Basic", "Standard", "Premium"], var.acr_sku)
    error_message = "acr_sku must be Basic, Standard or Premium."
  }
}

variable "grant_acr_push" {
  description = "Also give the VM identity AcrPush so you can build images ON the VM and push them. Set false once images are built elsewhere (e.g. a pipeline)."
  type        = bool
  default     = true
}
